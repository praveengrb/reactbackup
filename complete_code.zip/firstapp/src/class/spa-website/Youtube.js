import React from 'react';
// can export class in two ways
// export default class

export default class Youtube extends React.Component{

    render (){
        return (
            <div>
                <h3>Youtube</h3>
                <p>
                    Content of youtube comes here ...
                </p>
            </div>
        );
    }
}

