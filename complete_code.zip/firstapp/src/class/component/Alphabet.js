import React from 'react';
// can export class in two ways
// export default class
import '../../index.css';
export default class Alphabet extends React.Component{
    /*
        padding : simple integer is px.
        string supports either % or px
    */
    render (){
        let alphabetStyle = {
            color:this.props.fcolor,
            backgroundColor:this.props.bcolor,
            float:"left",
            display: "block",
            padding:"5px",
            margin:"50%",
    
        }
         return (
             <div>
                <div className="myAlpha">
                    <h1 >{this.props.children}</h1>
                </div>
                <div style={alphabetStyle}>
                            <h1 >{this.props.children}</h1>
                </div>
            </div>
         );
    }
}

