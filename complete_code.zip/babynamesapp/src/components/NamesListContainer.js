import React from 'react'

import {connect} from 'react-redux';
import { bindActionCreators } from 'redux'
import addFavoritesAction from '../actions/NameSelectionActions';
import addTextFilterAction from '../actions/FilterAction';

import Name from "./Name";

class NamesListContainer extends React.Component{

    renderNames = function() {
            /*
             return (
                    <li key={nm.id} className={nm.sex} onClick={() => this.props.addFavorites(nm)}
                    > {nm.name}</li>);
            */
           let babyNames=[];
            if(!this.props.filteredName){
                console.log("filter value not present")
                babyNames=this.props.names;
            } else{
                console.log("filter value  present");
                this.props.names.forEach(e => {
                    let nme=e.name.toLowerCase();
                    if(nme.includes(this.props.filteredName.toLowerCase())){
                        babyNames.push(e);
                    }
                    
                });
            }
           return babyNames.map(
                (nm)=>{
                    return (<Name 
                        key={nm.id} 
                        id={nm.id} 
                        sex={nm.sex} 
                        name={nm.name}
                        handleFavourite={() => this.props.addFavorites(nm)} 
                        />);
                }
            );

     

     }

    render() {
        return (
            <div className="App">
               {this.renderNames()}
            </div>
        );
    }    
}

function covertStateToProps(state){
    return {
        names:state.names,
        filteredName:state.filteredName
    };
}

function mapActionsToProps(dispatch){
    return bindActionCreators(
        {
        addFavorites:addFavoritesAction,
        textFilter:addTextFilterAction
    },dispatch
  );
}





export default connect(covertStateToProps,mapActionsToProps) (NamesListContainer)