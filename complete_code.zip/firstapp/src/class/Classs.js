import React from 'react';

import '../index.css';

import Header from './Header'
import FirstClass from './FirstClass';
// if two files with same export name, then have an alias name
import PropsExample from './PropsExample'

import EventExample from './EventExample';

import JSONExample from './JSONExample';

import CustomStyleSheet from './CustomStyleSheet'
//import registerServiceWorker from './registerServiceWorker';

import BehindTheScenes from './BehindTheScenes'
import BehindTheScenesWithClassName from './BehindTheScenesWithClassName'
import ComponentLifeCycle1 from './ComponentLifeCycle1'
import Comment from '../excercise1/Comment'

import LocalJson from './LocalJson'

import RemoteData from './RemoteData'

export default class Classs extends React.Component{
render(){
    return(<div>
   <Header />
   <LocalJson/>
   <RemoteData />
   <CustomStyleSheet/>
   <EventExample />
   <JSONExample />
  
   <FirstClass />
   <PropsExample name="Praveen">SA</PropsExample>
   <Comment cAuthorTitle="Mr" cAuthorName="Praveen" cEmotion="Angry" cActionLike="Like" cActionUnlike="Unlike" >I feel I did it correct </Comment>
   </div>   
);

}
}