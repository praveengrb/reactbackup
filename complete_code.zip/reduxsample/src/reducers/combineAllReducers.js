import { combineReducers } from 'redux';

import UserReducer from './UserReducers';
import MoviesReducers from './MoviesReducers';
import UserClickedReducer from "./reducer-userClicked";

const allReducers = combineReducers ({
    users:UserReducer,
    movies:MoviesReducers,
    activeuser:UserClickedReducer
})

export default allReducers;