export default function(state=null,action){
    switch (action.type){
        case "NAME_FILTERED":
            return action.filteredName;
        default:
            break;
    }
    return state;
}