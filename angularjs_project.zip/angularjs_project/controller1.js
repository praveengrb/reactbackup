var app = angular.module('myapp');
app.controller('controllerone',controlleroneFn);
function controlleroneFn($scope,variableExchange,$http,myService){
	var exchange=variableExchange;
	console.log("one")
	$scope.firstName="Praveen"
	
	$scope.testVariable = exchange.testVariable;
	
	exchange.setFirstName("praveen");
	console.log(exchange)
	console.log(exchange.rpt);
	$scope.forDetails=[];
	$scope.getRemoteData = function(){
		console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
		$http.get("https://jsonplaceholder.typicode.com/users")
			.then(function(response){
				console.log(response.data);
				$scope.forDetails = response.data;
			})
	}
	
	$scope.Response = function () {
		console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
		var myData =myService.serverCall();
		myData.then(function (result) {
                $scope.forDetails = result;
				
                
        });
	}
	
}


app.factory('myService', function ($http) {
        return {
            // 1st function
            serverCall: function () {
                return $http.get('https://jsonplaceholder.typicode.com/users').then(function (response) {
                    alert(response.data);
                    return response.data;
                });
            },
           
        };
    });