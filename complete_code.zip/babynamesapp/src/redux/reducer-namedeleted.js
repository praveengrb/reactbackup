export default function(state=null,action){
    switch (action.type){
        case "NAME_DELETED":
        return action.deletedName;
        default:
            break;
    }
    return state;
}