var app= angular.module("myapp");

app.service('ContactCrudService',ContactCrudServiceImpl);

function ContactCrudServiceImpl(){
	var contacts = [
	{'name':'Praveen','email':'praveengrb@gmail.com','phone':'9952749714'},
	{'name':'Guru','email':'praveengrb@gmail.com','phone':'9952749714'},
	{'name':'Ramnath','email':'praveengrb@gmail.com','phone':'9952749714'},
	{'name':'Balaji','email':'praveengrb@gmail.com','phone':'9952749714'}
	
	];
	
	this.getAll = function(){
		return contacts;
	}
	
	this.add = function(c){
		if(typeof c.index =='undefined')
			contacts.push(c);
		else 
			contacts[c.index]=c;
	}

	this.del = function(index){
		contacts.splice(index,1);
	}	
	
	this.edit = function(index){
		var contact=contacts[index];
		return contact;
	}	
}