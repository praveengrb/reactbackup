import React from 'react'

import addFavoritesAction from '../actions/NameSelectionActions';
import deleteFavoritesAction from '../actions/DeleteFavoritesAction';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux'
class Name extends React.Component{
    render() {
        return (
            <li 
            key={this.props.key} 
            className={this.props.sex}
            onClick={() => this.props.handleFavourite(this.props.name)} 
            > {this.props.name}</li>);
    }  
}

function addState(state){
    return state;
}

function mapActionsToProps(dispatch){
    return bindActionCreators(
        {
        addFavorites:addFavoritesAction,
        deleteFavorites:deleteFavoritesAction
    },dispatch
  );
}


export default connect(addState,mapActionsToProps)(Name);