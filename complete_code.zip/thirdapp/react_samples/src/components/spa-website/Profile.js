import React from 'react';



class Profile extends React.Component {
    

    render() { 
        return (
            <div>
                <h3>Profile</h3>
                <p>
                    Content for Profile comes here...
                </p>
        

            </div>    
          );
    }
}
  
export default Profile;