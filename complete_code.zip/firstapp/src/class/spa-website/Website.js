import React from 'react';
// can export class in two ways
// export default class

/*
Hash router will maintain the front back of the navigation
*/

import {HashRouter,NavLink,Route} from 'react-router-dom'
import Youtube from "./Youtube"
import Profile from "./Profile"
import Friends from "./Friends"
import Home from "./Home"

import "./spa.css"

export default class Website extends React.Component{

    render (){
        return (
            /*
            <ul>
                    <li><a to="#">Home</a></li>
                    <li><a to="#">Profile</a></li>
                    <li><a to="#">Friends</a></li>
                    <li><a to="#">Youtube</a></li>
                </ul>
            Step 1 : add Hash router.
            Step 2: react do not understand a href. so it has to be replaced with nav link
            Step 3: It donot understand href so change it to TO.
            Step 4: replace # wutg respective url and setup routes
            Step 5: Add routes
            
            exact property matches perfect value i.e, 
            if exact not present, content of Home and Profile / Youtube / Friends will be combinely printed
            */
            <HashRouter> 
            <div>
                <h1>SPA Website</h1>
                <ul className="menuheader" id="navigationHeader" >
                    <li><NavLink exact to="/">Home</NavLink></li>
                    <li><NavLink to="/profile">Profile</NavLink></li>
                    <li><NavLink to="/friends">Friends</NavLink></li>
                    <li><NavLink to="/youtube">Youtube</NavLink></li>
                </ul>
                

                <div>
                    <Route exact path="/" component={Home}></Route>
                    <Route path="/youtube" component={Youtube}></Route>
                    <Route path="/friends" component={Friends}>
                            <Route path="/praveen" component={Youtube}></Route>
                            <Route path="/balaji" component={Youtube}></Route>
                            <Route path="/hariharan" component={Youtube}></Route>
                    </Route>
                    <Route path="/profile" component={Profile}></Route>
                </div>    

            </div>
            </HashRouter>
        );
    }
}

