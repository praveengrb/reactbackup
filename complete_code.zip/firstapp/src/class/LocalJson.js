import React from 'react';
// can export class in two ways
// export default class

import jsondata from  "../data/data.json";

export default class LocalJson extends React.Component{
    componentWillMount(){
        console.log("Data "+jsondata);
    }

    formListWithLambda = function (){
        return jsondata.map((mydata) =>{
            return (
                <li> One </li>
            );       
        } )

    }

    formListWithLambda1 = function (){
        // map requires key
        return jsondata.map((mydata) =>{
            return (

                <li key={mydata.id}> {mydata.title} </li>
            );       
        } )

    }
    callMe(){
        console.log("Called");
    }
    formListWithLambda2 = function (){
        // map requires key
        return jsondata.map((mydata) =>{
            return (

                <li onClick={this.callMe} key={mydata.id}> {mydata.title} </li>
            );       
        } )

    }

    callMeEvent(e ){
        console.log("Called with event " );
        console.log(e);
    }
    formListWithLambda3 = function (){
        // map requires key
        return jsondata.map((mydata) =>{
            if(mydata.id ===4)
            return (
                
                <li onClick={this.callMeEvent} key={mydata.id}> {mydata.title} </li>
            );       
        } )

    }


    callMeEvent1(e ){
        console.log("Called with event " );
        console.log(e);
    }
    formListWithLambda4 = function (){
        // map requires key using legacy code.
        // if we want to use legacy function then put .bind explicitly
        return jsondata.map(function (mydata) {
           
                return <li onClick={this.callMeEvent} key={mydata.id}> {mydata.title} </li>
                
        }.bind(this) )

    }



    render (){
     

    return (<div>
        <h1>Local Json Example</h1>
        <ol>
            {this.formListWithLambda()}
        </ol>    
        <ol>
            {this.formListWithLambda1()}
        </ol>
        <ol>
            {this.formListWithLambda2()}
        </ol>    
        <ol>
            This is a lambda function
            {this.formListWithLambda3()}
        </ol>    

         <ol>
            This is the native function
            {this.formListWithLambda4()}
        </ol> 

    </div>);
    }
}