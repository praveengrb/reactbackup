import React from 'react';
// can export class in two ways
// export default class

export default class BehindTheScenesWithClassName extends React.Component{

    render (){
          //  <div>
        //<h1> Behind the scenes</h1>
          // </div>
        // return React.createElement('div',null,'h1' ,'Behind the scenes' );
        // above creates h1 as a text rather than element

        return React.createElement('div',{className:"one"},React.createElement('h1',{className:"two"},'Behind the scenes') );
    }
}

