import React from 'react';
// can export class in two ways
// export default class
class Header extends React.Component{

    render (){
         return (
            <div>
                Hello This is Hello world
            </div>
         );
    }
}


export default Header