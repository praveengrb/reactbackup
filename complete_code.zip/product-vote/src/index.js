import React from 'react';
import ReactDOM from 'react-dom';
import 'semantic-ui-css/semantic.min.css'
import './index.css';
import ProductList from './classs/ProductList'

import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(<ProductList />, document.getElementById('content'));
registerServiceWorker();
