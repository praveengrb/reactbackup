import React, { Component } from 'react';

class JSONExample extends Component {
  /*
  Any variable declared should be declared only in constructor.
  if a variable has frequent updates, then go with state
  Props is mandatory.
  Context is optional
  */

  constructor(props,context){
    super(props);
    this.state = {
      counter:0,
      user:{
        name:"Praveen",
        age:28
      },
      users:[
        {
          name:"Praveen",
          age:28
        },
        {
          name:"Praveen1",
          age:28
        }
      ]
    };
    /*
     * Bind the function that would be using these variables 
     */
    this.clickMe=this.clickMe.bind(this);
  }
 
  clickMe = function (){
    console.log("Old Value" +this.state.counter);
      /*
        this.state.counter will work only internally. i.e,
        the scope is private. and 
        this.state.counter ++;
        so if you want to modify , say setState
      */
     var newCounter = this.state.counter+1;
     console.log(this.state.user); 
     console.log(this.state.user.name); 
     console.log(this.state.users); 
     console.log(this.state.users[0]); 
     this.setState(
        {counter:newCounter}
      );
  }
  render() {
    return (
      <div>
      <button onClick={this.clickMe}>ClickMe</button>
      <h1> Incremented Value {this.state.counter} </h1>
      </div>
    );
  }
}

export default JSONExample;
