import React from 'react';
// can export class in two ways
// export default class

export default class CommentAuthor extends React.Component{

    render (){

         return (
             <div>
               {this.props.cAuthorTitle} . {this.props.children}
            </div>
         );
    }
}