import React from 'react';
// can export class in two ways
// export default class

export default class Profile extends React.Component{

    render (){
        return (
            <div>
                <h3>Profile</h3>
                <p>
                    Content of Profile comes here ...
                </p>
            </div>
        );
    }
}

