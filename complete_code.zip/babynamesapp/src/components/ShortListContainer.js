import React from 'react'
import {connect} from 'react-redux';
import Name from "./Name";

import { bindActionCreators } from 'redux'
import deleteFavoritesAction from '../actions/DeleteFavoritesAction';

class ShortListContainer extends React.Component{
    constructor(props){
        super(props);
        this.state={
            shortListedNames:[],
            deselectedName:{}
        }
    }

    addNameToCollection = function(n){
        console.log("names" + n );
        console.log("Delselected Name "+JSON.stringify(this.props.deselectedName))
        console.log("test 1 "+JSON.stringify(this.state.shortListedNames))
        
    if(this.props.deselectedName==null){
        console.log("Selected Name" +this.state.shortListedNames.indexOf(n.id));
        console.log("Selected Test" +this.state.shortListedNames.indexOf(n.name));
            if(this.state.shortListedNames.indexOf(n.id) === -1
            && this.state.shortListedNames.indexOf(n.name)===-1){
                this.state.shortListedNames.push(n);
                console.log(this.state.shortListedNames);
            }
    } 

    else {
        const index = this.state.shortListedNames.indexOf(this.props.deselectedName.id);
        console.log("Has Favorite " + index)
            console.log("Deselected Name " );
            console.log(this.props.deselectedName);
            var removeIndex = this.state.shortListedNames.map(function(item) { return item.id; }).indexOf(this.props.deselectedName.id);
            this.state.shortListedNames.splice(removeIndex, 1);
           
        //}
    }  
       
    
 
    }
    renderFavorites = function(){
        return this.state.shortListedNames.map(
            (nm)=>{
                return (<Name 
                    key={nm.id} 
                    id={nm.id} 
                    sex={nm.sex} 
                    name={nm.name} 
                    handleFavourite={() =>this.props.deleteFavorites(nm)}/>);
            }
        )
    }

    render(){

        if(!this.props.selectedNames){
            return(<div className="favourites"> 
            <h4>
                Click on a name to shortlist it..
            </h4>    
            </div>);
        } else{
        this.addNameToCollection(this.props.selectedNames);
        return (
            <div className="favourites">
            <h4>
            Your Shortlist : 
            </h4>
            <ul>
            {this.renderFavorites()}
            </ul>
            </div>    

        );
    }
    }
}

function convertStateToProps(state){
    console.log("Selected Name :");
    console.log(state);
    return ({
        selectedNames:state.selectedName,
        deselectedName:state.deletedName
    });
}

function mapActionsToProps(dispatch){
    return bindActionCreators(
        {
        deleteFavorites:deleteFavoritesAction
    },dispatch
  );
}


export default connect (convertStateToProps,mapActionsToProps) (ShortListContainer);