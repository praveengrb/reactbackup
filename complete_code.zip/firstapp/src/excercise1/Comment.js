import React from 'react';
// can export class in two ways
// export default class
import CommentAuthor from "./CommentAuthor"
import CommentText from "./CommentText"
import CommentActions from "./CommentActions"
export default class Comment extends React.Component{

    render (){

         return (
             <div>
                <CommentAuthor cAuthorTitle={this.props.cAuthorTitle} > {this.props.cAuthorName} </CommentAuthor>
                <CommentText cEmotion={this.props.cEmotion} cComments={this.props.children}> {this.props.children} </CommentText>
                <CommentActions lButtonName={this.props.cActionLike} uButtonName={this.props.cActionUnlike} > </CommentActions>
            </div>
         );
    }
}

