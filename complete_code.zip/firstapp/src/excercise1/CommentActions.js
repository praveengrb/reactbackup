import React from 'react';
// can export class in two ways
// export default class

export default class CommentActions extends React.Component{

  constructor(props,context){
    super(props);
    this.state = {
      likeCount:0,
      disLikeCount:0
    };
    /*
     * Bind the function that would be using these variables 
     */
    this.likeCounter=this.likeCounter.bind(this);
    this.disLikeCounter=this.disLikeCounter.bind(this);
    }
    likeCounter = function (){
        console.log("Old Value" +this.state.likeCount);
        /*
          this.state.counter will work only internally. i.e,
          the scope is private. and 
          this.state.counter ++;
          so if you want to modify , say setState
        */
       var newCounter = this.state.likeCount+1;
        
       this.setState(
          {likeCount:newCounter}
        );
    }
    disLikeCounter = function (){
        console.log("Old Value" +this.state.disLikeCount);
        /*
          this.state.counter will work only internally. i.e,
          the scope is private. and 
          this.state.counter ++;
          so if you want to modify , say setState
        */
       var newCounter = this.state.disLikeCount+1;
        
       this.setState(
          {disLikeCount:newCounter}
        );
    }

    render (){

         return (
             <div>
               <label>Like Count: {this.state.likeCount} </label>  
               <button onClick={this.likeCounter}> {this.props.lButtonName} </button>
               <label> Unlike Like Count: {this.state.disLikeCount}</label>  
               <button onClick={this.disLikeCounter}> {this.props.uButtonName} </button>
            </div>
         );
    }
}
