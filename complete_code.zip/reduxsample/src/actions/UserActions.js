const clickUserAction = function(user){
    console.log("User Clicked : " + user.fName );

    return ({
        type : "USER_CLICKED",
        myData:user
    })

}

export default clickUserAction;