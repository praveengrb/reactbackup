import React from 'react';
// can export class in two ways
// export default class

export default class Home extends React.Component{

    render (){
        return (
            <div>
                <h3>Home</h3>
                <p>
                    Content of Home comes here ...
                </p>
            </div>
        );
    }
}

