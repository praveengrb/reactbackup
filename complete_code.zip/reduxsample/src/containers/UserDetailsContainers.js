import React from 'react';
import {connect} from 'react-redux';

class UserDetailsContainers extends React.Component{
    render(){
        if(!this.props.clickedUser){
            return(<div> 
            
               Click on Any User
                
            </div>);
        } else{

            return(<div> 
            
                Details of the clicked User

                <p>ID: {this.props.clickedUser.id}</p>
                <p>User Name: {this.props.clickedUser.fName} , {this.props.clickedUser.lName} </p>
                <p>Age : {this.props.clickedUser.age} </p>
                <p>Description : {this.props.clickedUser.description} </p>

            </div>);
        }

    }
}

function convertStateToProps(state){
    console.log("User Details :" + state);
    return ({
        clickedUser:state.activeuser
    });
}

export default connect (convertStateToProps) (UserDetailsContainers);