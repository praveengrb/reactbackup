import React from 'react';


class Youtube extends React.Component {
    

    render() { 
        return (
            <div>
                <h3>Youtube</h3>
                <p>
                    Content for Youtube comes here...
                </p>
        

            </div>    
          );
    }
}
  
export default Youtube;