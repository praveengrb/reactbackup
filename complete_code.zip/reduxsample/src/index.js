import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import MainComponent from './components/MainComponent';
import registerServiceWorker from './registerServiceWorker';

import {Provider} from 'react-redux';
import { createStore } from 'redux'; 
import allReducers from './reducers/combineAllReducers';

const reduxStore = createStore(allReducers);


ReactDOM.render(
<Provider store={reduxStore}>
    <div> 
        <MainComponent />

    </div>
</Provider>
, document.getElementById('root'));
registerServiceWorker();
