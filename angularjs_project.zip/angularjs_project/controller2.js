var app = angular.module('myapp');
app.controller('controllerTwo',controllerTwoFn);
function controllerTwoFn($scope,variableExchange){
	var exchange=variableExchange;
	console.log("two")
	$scope.lastName="Sankarasubramanian"
	console.log(exchange)
	console.log(exchange.rpt);
	$scope.rpt = exchange.rpt;
}