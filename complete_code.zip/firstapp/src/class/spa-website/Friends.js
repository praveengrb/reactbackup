import React from 'react';
// can export class in two ways
// export default class

export default class Friends extends React.Component{

    render (){
        return (
            <div>
                <h3>Friends</h3>
                <p>
                    Content of Friends comes here ...
                </p>
            </div>
        );
    }
}

