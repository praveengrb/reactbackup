var app = angular.module('myapp');
app.service('variableExchange',serviceFn);
function serviceFn(){
	var exchange = {};
	exchange.testFunction = function() {
		console.log("Hello from service")
	}
	exchange.testVariable="I am from test";
	
	// adding function to create full name
	exchange.rpt=null;
	exchange.setFirstName=function(rpt){
		console.log("service "+rpt)
		exchange.rpt=rpt;
	}
	
	return exchange;
	
	
}