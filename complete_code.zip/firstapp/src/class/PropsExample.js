import React, { Component } from 'react';
import '../App.css';

class PropsExample extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <h1 className="App-title">First component</h1>
        </header>
        <p>Topics afdasd</p>
        <p> {this.props.name}</p> is a <p> {this.props.children} </p>
      </div>
    );
  }
}

export default PropsExample;
