var app = angular.module("myapp",[])
app.controller('ContactCrudController',contactCrudFunction)
function contactCrudFunction($scope, ContactCrudService){
	var ccs = ContactCrudService;
	
	$scope.contacts = ccs.getAll(); 
	$scope.addContact = function(){
			ccs.add($scope.newcontact);
			alert("Contact Added"+JSON.stringify($scope.newcontact));
		

		$scope.newcontact={};
	}
	
	$scope.editContact = function(index) {
		alert("Edit contact called");
		$scope.newcontact=ccs.edit(index);
		$scope.newcontact.index=index;
	}	
	
	$scope.deleteContact = function(index) {
		alert("Delete contact called");
		ccs.del(index);
	}	
		
}	