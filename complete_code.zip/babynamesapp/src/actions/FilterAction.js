const addTextFilterAction = function(name){
    console.log("Selected Name @filter: "  );
    console.log(name);
    return ({
        type : "NAME_FILTERED",
        filteredName:name
    })

}
export default addTextFilterAction;