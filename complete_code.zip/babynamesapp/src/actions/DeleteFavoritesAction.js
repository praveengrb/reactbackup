const deleteFavoritesAction = function(name){
    console.log("Selected Name : "  );
    console.log(name);
    return ({
        type : "NAME_DELETED",
        deletedName:name
    })

}
export default deleteFavoritesAction;