const addFavoritesAction = function(name){
    console.log("Selected Name : "  );
    console.log(name);
    return ({
        type : "NAME_SELECTED",
        selectedName:name
    })

}




export default addFavoritesAction;