import React from 'react';
// can export class in two ways
// export default class

export default class CommentText extends React.Component{

    render (){

         return (
             <div>
              <textarea rows="4" cols="50" >
                    {this.props.cComments}
                    
               </textarea>
            </div>
         );
    }
}