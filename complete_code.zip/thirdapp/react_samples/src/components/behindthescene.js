import React from 'react'


class BehindTheScene extends React.Component{

 

    render(){
       /*  return(
            <div>
                <h1>Behind The Scenes</h1>
               
           </div>
        ); */
        return React.createElement('div',{className:'one'},
                React.createElement('h1', {className:'two'}, 
                                    'Behind The Scenes'));

    }

}

export default BehindTheScene;