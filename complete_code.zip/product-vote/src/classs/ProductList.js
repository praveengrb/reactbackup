import React from 'react';
import Product from './Product';
import Seed from  "./seed.json";
export default class ProductList extends React.Component {
   
    // Local json we load and we do modification in that itself
    componentWillMount () {
        Seed.forEach(element => {
            element.votes = Math.floor((Math.random() * 50) + 15);
        });
    }
    constructor (props){
        super(props)
        this.setState({
            stateProducts:[]
        });
    }
    /* Handle product Up vote. We want to vote up and down */

    upVote = function(productId){
        console.log("product id " + productId + " was up voted");
        //let newStateProducts = Seed;
        //this.setState({stateProducts:newStateProducts})
    }
   
    renderProducts = function (){
        let newProducts = Seed.sort((a, b) => (
            b.votes - a.votes
            ));
        console.log(JSON.stringify(newProducts))
        
        return newProducts.map((products) =>{
            return (
                <Product 
                key={'product-' + products.id}
                id={products.id}
                title={products.title}
                description={products.description}
                url={products.url}
                votes={products.votes}
                avatar={products.submitterAvatarUrl}
                image={products.productImageUrl}
                onVote={this.upVote}
                />
            );       
        } )

       

    }

    render() {
       
        return (
        <div className='ui unstackable items'>
            {this.renderProducts()}
        </div>
        );
    }
}
    