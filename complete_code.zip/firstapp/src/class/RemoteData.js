import React from 'react';
import axios from 'axios';

export default class RemoteData extends React.Component{
    constructor(props){
        super(props)
        this.state = {
            users:[],
            users1 : []
        }
    }
    getRemoteData(){
        axios.get(
            "https://jsonplaceholder.typicode.com/users"
        ).then((response) =>
            {
                
                console.log("Response " + response.data)
                console.log(response.data)
                this.setState({users:response.data})
            }
        );
    }
    componentWillMount(){
        this.getRemoteData() // s
        this.getRemoteData1()

    }

    dumpJson(){
        console.log(this.state.users)
        let urs = [];
        urs.push( this.state.users );

        console.log(JSON.stringify(urs))
        //return <p> {urs} </p>
        ///return <p> {this.state.users} </p>
    }

    renderAsLi(){
        return this.state.users1.map((mydata) =>{
            return (

                <li key={mydata.id}> {mydata.name} </li>
            );       
        } )

    }


    renderAsTable(){
        return this.state.users1.map((mydata) =>{
            return (

                <tr><td>{mydata.id}</td><td>{mydata.name}</td><td>{mydata.username}</td>
                <td>{mydata.email}</td><td>{mydata.address.geo.lat},{mydata.address.geo.long}</td></tr>
            );       
        } )

    } 
    getRemoteData1(){
        axios.get(
            "https://jsonplaceholder.typicode.com/users"
        ).then((response) =>
            {
                
                console.log("Response " + response.data)
                console.log(response.data)
                this.setState({users1:response.data})
            }
        );
    }
    render (){
        return (
            <div>
                <h1>Remote Data</h1>
                {this.dumpJson()}
                <ol>
                {this.renderAsLi()}
                </ol>

                <table>
                <thead>
                <tr><th>id</th><th>name</th><th>username</th><th>email</th><th>lat/long</th></tr>    
                </thead>
                <tbody>
                {this.renderAsTable()}
                </tbody>
                </table>    
            </div>
        );
    }
}

