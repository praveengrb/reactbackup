import React from 'react';

import {connect} from 'react-redux';
import clickUserAction from '../actions/UserActions';
import { bindActionCreators } from 'redux';



class UserListContainer extends React.Component{
    renderUsers = function() {
    
       return this.props.myUsers.map(
            (mydata)=>{
                return (
                <li key={mydata.id}
                onClick={() => this.props.clickUserProp(mydata)}
                > {mydata.fName}  {mydata.lName}  </li>);
            }
        );
    }

    renderMovies = function() {
        return this.props.myMovies.map(
             (mydata)=>{
                 return (<li key={mydata.id}> {mydata.description} </li>);
             }
         );
     }


    render(){
        return(<div> 
            
            User List will be there
            <ul>
            {this.renderUsers()}
            </ul>
            Movie Lists
            <ul>
            {this.renderMovies()}
            </ul>
        </div>);
    }

}
function covertStateToProps(state){
    console.log(state)
    return {
        myUsers:state.users,
        myMovies:state.movies
    };
}

function mapActionsToProps(dispatch){
    return bindActionCreators(
        {
        clickUserProp:clickUserAction
    },dispatch
  );
}


export default connect(covertStateToProps,mapActionsToProps)(UserListContainer);