import React from 'react';
import Alphabet from './component/Alphabet';
// can export class in two ways
// export default class
class CustomStyleSheet extends React.Component{

    render (){
         return (
            <div>
                <Alphabet fcolor="red" bcolor="yello">H</Alphabet>
                <Alphabet fcolor="yellow" bcolor="blue">O</Alphabet>
                <Alphabet fcolor="blue" bcolor="yellow">M</Alphabet>
                <Alphabet fcolor="green" bcolor="yellow">E</Alphabet>
                <Alphabet fcolor="orange" bcolor="blue">Programmer</Alphabet>
                <Alphabet fcolor="indigo" bcolor="yellow">Architect</Alphabet>
                <Alphabet fcolor="purple" bcolor="yellow">Architect</Alphabet>
            </div>
         );
    }
}


export default CustomStyleSheet