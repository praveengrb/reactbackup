import React from 'react';


class Friends extends React.Component {
    

    render() { 
        return (
            <div>
                <h3>Friends</h3>
                <p>
                    Content for Friends comes here...
                </p>
        

            </div>    
          );
    }
}
  
export default Friends;