import React from 'react';
import ReactDOM from 'react-dom';
import UserListContainers from "../containers/UserListContainers"
import UserDetailsContainers from '../containers/UserDetailsContainers';

export default class MainComponent extends React.Component {


    render() {
        return (
            <div>
                <div>
                    <p> User List Container  </p>
                    <UserListContainers />
                </div>
                <div>
                    <p> User List Details </p>
                    <UserDetailsContainers/>
                </div>  
            </div>
        );
    }
}