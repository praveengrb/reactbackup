import React, { Component } from 'react'
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux'
import addTextFilterAction from '../actions/FilterAction';

class SearchContainer extends React.Component{

    
    selectedName = function(filterVal){
        
        //if(filterVal.length > 2){
            console.log("Selected Name @@ " + filterVal)
            this.props.textFilter(filterVal);
        //}

    }
    render(){
        const { filterVal, filterUpdate} = this.props
        return (
            <div>
                <input type="text" 
          ref='filterInput'
          placeholder='Type to filter..'
          onChange={() => {
            this.selectedName(this.refs.filterInput.value) 
          }}
          />
            </div>    

        );
    }
}


function mapActionsToProps(dispatch){
    return bindActionCreators(
        {
        textFilter:addTextFilterAction
    },dispatch
  );
}

function addState(state){
    return state;
}


export default connect(addState,mapActionsToProps) (SearchContainer);