import { combineReducers } from 'redux';

import NamesReducers from './NamesReducers';

import NameSelectedReducer from './reducer-nameselected';

import FilteredText from './reducer-filteredname';

import NameDeletedReducer from './reducer-namedeleted';


const allReducers = combineReducers ({
    names:NamesReducers,
    selectedName:NameSelectedReducer,
    deletedName:NameDeletedReducer,
    filteredName:FilteredText
})

export default allReducers;