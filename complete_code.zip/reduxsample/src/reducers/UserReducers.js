export default function (){
    return [
        {
            id:1,
            fName:"praveen",
            lName:'sankarasubramanian',
            age:28,
            description: 'Exporting reduxer'
        },        {
            id:2,
            fName:"praveen2",
            lName:'sankarasubramanian',
            age:28,
            description: 'Exporting reduxer'
        },        {
            id:3,
            fName:"praveen3",
            lName:'sankarasubramanian',
            age:28,
            description: 'Exporting reduxer'
        },        {
            id:4,
            fName:"praveen4",
            lName:'sankarasubramanian',
            age:28,
            description: 'Exporting reduxer'
        }


    ]

}