import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import Website from './class/spa-website/Website';
import Classs from './class/Classs';


const position = document.getElementById('root');
const spa = document.getElementById('spa');

ReactDOM.render(
    <div>
        <Website/>
            
       </div>   
    , spa);


ReactDOM.render(
<div>
    <Classs/>
        
   </div>   
, position);
//registerServiceWorker();
