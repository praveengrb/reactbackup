import React from 'react';



class Home extends React.Component {
    

    render() { 
        return (
            <div>
                <h3>Home</h3>
                <p>
                    Content for Home comes here...
                </p>
        

            </div>    
          );
    }
}
  
export default Home;