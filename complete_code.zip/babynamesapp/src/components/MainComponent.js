import React from 'react';
import ReactDOM from 'react-dom';
import NamesListContainer from './NamesListContainer';
import SearchContainer from './SearchContainer';
import ShortListContainer from './ShortListContainer';


export default class MainComponent extends React.Component {


    render() {
        return (
            <div>
                <header>
                <SearchContainer/>
                </header>

                <main>
                  <ShortListContainer/>
                  <NamesListContainer/>
                </main>
            </div>
        );
    }
}