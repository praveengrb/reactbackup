import React from 'react';
import ReactDOM from 'react-dom';

// can export class in two ways
// export default class
class ComponentLifeCycle1 extends React.Component{
    componentWillMount(){
        console.log("Component  will mount");
    }

    componentDidMount(){
        console.log("Component mounted");
    }

    componentWillUpdate(){
        console.log("component will update");
    }
    shouldComponentUpdate(newProps,newState){
        console.log("Components can update");
        if(newState.counterNumber < 4){
            console.log("Components can update");
            return true;
        } else
        {
            console.log("Components should not update");
            ReactDOM.unmountComponentAtNode(document.getElementById("unmountThisDiv"));
          return false;
        }
      }
    constructor (props){
        super(props);
        this.state={
            counterNumber:0
        };
        this.changeNumber = this.changeNumber.bind(this);
    }
    changeNumber = function (){
        let newNumber = this.state.counterNumber + 1;
        this.setState({counterNumber:newNumber});
    }
    render (){
         return (
            <div >
                <h1> Component Life Cycle </h1>
                <button onClick={this.changeNumber}>Click Way {this.state.counterNumber}</button>
            </div>
         );
    }
}


export default ComponentLifeCycle1