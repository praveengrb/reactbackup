import React, { Component } from 'react';
import '../App.css';

class FirstClass extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <h1 className="App-title">First component</h1>
        </header>
        <p>Topics covered</p>
        <ul>
        <li>Praveen1</li>
        <li>Praveen2</li>
        <li>Praveen3</li>
        <li>Praveen4</li>
        </ul>
      </div>
    );
  }
}

export default FirstClass;
