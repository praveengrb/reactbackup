import React from 'react';
// can export class in two ways
// export default class

export default class BehindTheScenes extends React.Component{

    render (){
          //  <div>
        //<h1> Behind the scenes</h1>
          // </div>
        // return React.createElement('div',null,'h1' ,'Behind the scenes' );
        // above creates h1 as a text rather than element

        return React.createElement('div',null,React.createElement('h1',null,'Behind the scenes') );
    }
}

